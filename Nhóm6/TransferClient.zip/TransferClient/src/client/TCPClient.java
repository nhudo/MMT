package client;


import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javax.swing.JTextArea;

import data.Data;
import data.DirectoryInfo;
import data.FileInfo;

public class TCPClient {
    // khởi tạo một đối tượng Socket đảm nhiệm vị trí client
    private Socket client;
    // host
    private String host;
    // cổng
    private int port;
    private JTextArea textAreaLog;

    // hàm khởi tạo nhận 3 giá trị host, post và textarea (là chỗ để thông báo mọi thứ về việc truyền nhận dữ liệu)
    // 3 cái này nhận từ bên phía giao diện của chương trình
    public TCPClient(String host, int port, JTextArea textAreaLog) {
        this.host = host;
        this.port = port;
        this.textAreaLog = textAreaLog;
    }
    
    public boolean connectServer() {
        try {
            client = new Socket(host, port);
            textAreaLog.append("Kết nối đến Server.\n");
            return true;
        } catch (UnknownHostException e) {
        	textAreaLog.append("Không thể kết nối!\n");
            e.printStackTrace();
            return false;
        } catch (IOException e) {
        	textAreaLog.append("Không thể kết nối!\n");
            e.printStackTrace();
            return false;
        }
    }

    // hàm gửi file nhận 2 tham số là đường dẫn của file cần gửi.
    // nơi lưu file cần gửi bên phía client
    public void sendFile(String sourceFilePath) {
        DataOutputStream outToServer = null;
        ObjectOutputStream oos = null;
        ObjectInputStream ois = null;

        try {
            // Gửi 1 thông báo đến Server
            outToServer = new DataOutputStream(client.getOutputStream());
            outToServer.writeUTF("Tin nhắn đến từ " + client.getLocalSocketAddress() + ": Bắt đầu gửi file...\n");

//            textAreaLog.append("Đang đóng gói dữ liệu...\n");
            // lấy file trong máy
            FileInfo fileInfo = getFileInfo(sourceFilePath);
            
            Data data = new Data();
            data.setFileinfo(fileInfo);
            data.setStatus(1);

//            textAreaLog.append("Bắt đầu gửi...\n");
            // Gửi data
            oos = new ObjectOutputStream(client.getOutputStream());
            oos.writeObject(data);

            // nhận về xác nhận đã nhận được file từ phía Server
            ois = new ObjectInputStream(client.getInputStream());
            
            // bên Server gửi lại 1 đối tượng Data bên trong chỉ chứa dữ liệu về biến status
            data = (Data) ois.readObject();
            if (data != null) {
            	int stt = data.getStatus();
            	if (stt == 0) {
            		textAreaLog.append("Gửi file thành công!\n");
            	}
            	else if (stt == -1){
            		textAreaLog.append("Người nhận không đồng ý nhận file!\n");
            	}
            }
            
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            // đóng tất cả stream
            closeStream(oos);
            closeStream(ois);
            closeStream(outToServer);
        }
    }
    
    public void SendDirectory(String sourceDirPath) {
    	DataOutputStream outToServer = null;
        ObjectOutputStream oos = null;
        ObjectInputStream ois = null;
        
        try {
            // Gửi 1 thông báo đến Server
            outToServer = new DataOutputStream(client.getOutputStream());
            outToServer.writeUTF("Tin nhắn đến từ " + client.getLocalSocketAddress() + ": Bắt đầu gửi thư mục...\n");
            
//            textAreaLog.append("Đang đóng gói dữ liệu...\n");
            // lấy dữ liệu của folder trong máy
            DirectoryInfo dirInfo = getDirInfo(sourceDirPath); 
            
            Data data = new Data();
            data.setDirinfo(dirInfo);
            // status = 2 -> truyền thư mục
            data.setStatus(2);
            
//            textAreaLog.append("Bắt đầu gửi...\n");
            // Gửi data
            oos = new ObjectOutputStream(client.getOutputStream());
            oos.writeObject(data);

            // nhận về xác nhận đã nhận được file từ phía Server
            ois = new ObjectInputStream(client.getInputStream());
            
            // bên Server gửi lại 1 đối tượng Data bên trong chỉ chứa dữ liệu về biến status
            data = (Data) ois.readObject();
            if (data != null) {
            	int stt = data.getStatus();
            	if (stt == 0) {
            		textAreaLog.append("Gửi thư mục thành công!\n");
            	}
            	else if (stt == -1){
            		textAreaLog.append("Người nhận không đồng ý nhận thư mục!\n");
            	}
            }
            
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            // đóng tất cả stream
            closeStream(oos);
            closeStream(ois);
            closeStream(outToServer);
        }
    }

    // lấy dữ liệu của file cần gửi từ đường dẫn sourceFilePath
    private FileInfo getFileInfo(String sourceFilePath) {

        FileInfo fileInfo = null;
        BufferedInputStream bis = null;

        try {
            File sourceFile = new File(sourceFilePath);
            bis = new BufferedInputStream(new FileInputStream(sourceFile));
            fileInfo = new FileInfo();
            byte[] fileBytes = new byte[(int) sourceFile.length()];
            
            // mang tiếng trong lớp FileInfo xây dựng nên mỗi file có đến mấy thuộc tính đi kèm
            // xong cần dùng mỗi tên với byte =)))
            bis.read(fileBytes, 0, fileBytes.length);
            fileInfo.setFilename(sourceFile.getName());
            fileInfo.setDataBytes(fileBytes);
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            closeStream(bis);
        }
        return fileInfo;
    }
    
    private DirectoryInfo getDirInfo(String sourceDirPath) {
    	// nếu ko có đường dẫn thì đọc cái mẹ gì, thêm vào ko tí lại dính lỗi nullpointerexception
    	if (sourceDirPath.equals("")) return null;
		
    	// tạo 1 đối tượng File từ đường dẫn trên
    	// đại diện cho cái thư mục hoặc file
		File files = new File(sourceDirPath);
		
		// tạo 1 đối tượng mới và khởi tạo vùng nhớ cho các ArrayList
		DirectoryInfo dir = new DirectoryInfo();
		dir.setFileindirectory(new ArrayList<FileInfo>());
		dir.setChilddirectory(new ArrayList<DirectoryInfo>());
		
		// lấy tên thư mục hiện tại
		dir.setName(files.getName());
		
		// lấy các thư mục và tệp là con trực tiếp của files
		File[] child = files.listFiles();
		for (File x : child) {
			// nếu là thư mục => đệ quy để lấy các tệp con của nó
			if (x.isDirectory()) {
				dir.getChilddirectory().add(getDirInfo(x.getPath()));
			}
			else { // nếu là tệp => lưu vào ArrayList
				
				// giống với việc lưu 1 tệp
				FileInfo fileInfo = null;
		        BufferedInputStream bis = null;

		        try {
		            bis = new BufferedInputStream(new FileInputStream(x));
		            fileInfo = new FileInfo();
		            byte[] fileBytes = new byte[(int) x.length()];
		            // lấy thông tin file
		            bis.read(fileBytes, 0, fileBytes.length);
		            fileInfo.setFilename(x.getName());
		            fileInfo.setDataBytes(fileBytes);
		            
		            // thêm vào trong Danh sách
		            dir.getFileindirectory().add(fileInfo);
		        } catch (IOException ex) {
		            ex.printStackTrace();
		        } finally {
		        	
		            closeStream(bis);
		        }
			}
		}
		
		return dir;
    }

    public void closeSocket() {
        try {
            if (client != null) {
                client.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void closeStream(InputStream inputStream) {
        try {
            if (inputStream != null) {
                inputStream.close();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void closeStream(OutputStream outputStream) {
        try {
            if (outputStream != null) {
                outputStream.close();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
