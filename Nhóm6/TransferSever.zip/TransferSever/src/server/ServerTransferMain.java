package server;

import javax.swing.JFrame;

public class ServerTransferMain {
	public static AcceptReceive ar = new AcceptReceive();
	public static ServerTransferView view = new ServerTransferView();
	public static void main(String[] args) {
		ar.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		ar.setVisible(false);
		view.setVisible(true);
        TCPServer tcpServer = new TCPServer();
        tcpServer.open();
        tcpServer.start();
    }
}
