package client;


import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import javax.swing.JScrollPane;

public class ClientTransferView extends JFrame {
    private static final long serialVersionUID = 1L;

    private JLabel labelHost;
    private JTextField textFieldHost;
    private JLabel labelPort;
    private JTextField textFieldPort;
    private JButton btnChonfile;
    private JTextField textFieldFilePath;
    private JButton btnSendFile;
    private JTextArea textAreaResult;
    private JScrollPane scrollPane;

    public ClientTransferView() {
    	setResizable(false);
    	getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 13));
    	try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e1) {
			e1.printStackTrace();
		}
    	
    	this.setLocation(500,200);
        setTitle("Client - truyền file bằng giao thức TCP/IP");
        labelHost = new JLabel("Host:");
        labelHost.setFont(new Font("Tahoma", Font.PLAIN, 13));
        textFieldHost = new JTextField();
        textFieldHost.setText("localhost");
        textFieldHost.setFont(new Font("Tahoma", Font.PLAIN, 13));
        labelPort = new JLabel("Port:");
        labelPort.setFont(new Font("Tahoma", Font.PLAIN, 13));
        textFieldPort = new JTextField();
        textFieldPort.setText("9900");
        textFieldPort.setFont(new Font("Tahoma", Font.PLAIN, 13));
        labelHost.setBounds(20, 20, 50, 25);
        textFieldHost.setBounds(60, 20, 100, 25);
        labelPort.setBounds(170, 20, 50, 25);
        textFieldPort.setBounds(209, 20, 50, 25);

        textFieldFilePath = new JTextField();
        textFieldFilePath.setFont(new Font("Tahoma", Font.PLAIN, 13));
        textFieldFilePath.setBounds(20, 60, 540, 25);
        btnChonfile = new JButton("Chọn file");
        btnChonfile.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent arg0) {
        		chooseFile();
        	}
        });
        btnChonfile.setFont(new Font("Tahoma", Font.PLAIN, 13));
        btnChonfile.setBounds(335, 100, 100, 25);
        btnSendFile = new JButton("Send");
        btnSendFile.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		String host = getTextFieldHost().getText().trim();
                int port = Integer.parseInt(getTextFieldPort().getText().trim());
                String sourcePath = getTextFieldFilePath().getText();
                File f = new File(sourcePath);
                if (host != "" && sourcePath != "" && f.exists()) {
                    TCPClient tcpClient = new TCPClient(host, port, getTextAreaResult());
                    if (tcpClient.connectServer()) {
                    	if (f.isDirectory()) {
                        	tcpClient.SendDirectory(sourcePath);
                        }
                        else {
                        	tcpClient.sendFile(sourcePath);
                        }
                        getTextAreaResult().append("Đóng kết nối\n");
                        tcpClient.closeSocket();
                    }
                    
                    
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Host, Port và filepath.");
                }
        	}
        });
        btnSendFile.setFont(new Font("Tahoma", Font.PLAIN, 13));
        btnSendFile.setBounds(20, 100, 81, 25);

        getContentPane().add(labelHost);
        getContentPane().add(textFieldHost);
        getContentPane().add(labelPort);
        getContentPane().add(textFieldPort);
        getContentPane().add(textFieldFilePath);
        getContentPane().add(btnChonfile);
        getContentPane().add(btnSendFile);
        
        scrollPane = new JScrollPane();
        scrollPane.setBounds(20, 140, 540, 145);
        getContentPane().add(scrollPane);
        textAreaResult = new JTextArea();
        textAreaResult.setWrapStyleWord(true);
        textAreaResult.setEditable(false);
        scrollPane.setViewportView(textAreaResult);

        getContentPane().setLayout(null);
        
        JButton btnChonThuMuc = new JButton("Chọn thư mục");
        btnChonThuMuc.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent arg0) {
        		chooseDir();
        	}
        });
        btnChonThuMuc.setFont(new Font("Tahoma", Font.PLAIN, 13));
        btnChonThuMuc.setBounds(445, 100, 115, 25);
        getContentPane().add(btnChonThuMuc);
        setSize(600, 350);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public void chooseFile() {
        final JFileChooser fc = new JFileChooser();
        fc.showOpenDialog(this);
        try {
            if (fc.getSelectedFile() != null) {
                textFieldFilePath.setText(fc.getSelectedFile().getPath());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void chooseDir() {
    	JFileChooser chooser = new JFileChooser();
	    chooser.setCurrentDirectory(new java.io.File("."));
	    chooser.setDialogTitle("choosertitle");
	    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	    chooser.setAcceptAllFileFilterUsed(false);
	    if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
	    	textFieldFilePath.setText(chooser.getSelectedFile().getAbsolutePath());
		}
    }

    public JLabel getLabelHost() {
        return labelHost;
    }

    public void setLabelHost(JLabel labelHost) {
        this.labelHost = labelHost;
    }

    public JTextField getTextFieldHost() {
        return textFieldHost;
    }

    public void setTextFieldHost(JTextField textFieldHost) {
        this.textFieldHost = textFieldHost;
    }

    public JLabel getLabelPort() {
        return labelPort;
    }

    public void setLabelPort(JLabel labelPort) {
        this.labelPort = labelPort;
    }

    public JTextField getTextFieldPort() {
        return textFieldPort;
    }

    public void setTextFieldPort(JTextField textFieldPort) {
        this.textFieldPort = textFieldPort;
    }

    public JButton getBtnBrowse() {
        return btnChonfile;
    }

    public void setBtnBrowse(JButton btnBrowse) {
        this.btnChonfile = btnBrowse;
    }

    public JTextField getTextFieldFilePath() {
        return textFieldFilePath;
    }

    public void setTextFieldFilePath(JTextField textFieldFilePath) {
        this.textFieldFilePath = textFieldFilePath;
    }

    public JButton getBtnSendFile() {
        return btnSendFile;
    }

    public void setBtnSendFile(JButton btnSendFile) {
        this.btnSendFile = btnSendFile;
    }

    public JTextArea getTextAreaResult() {
        return textAreaResult;
    }

    public void setTextAreaResult(JTextArea textAreaResult) {
        this.textAreaResult = textAreaResult;
    }
}
