package server;

import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.io.File;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class AcceptReceive extends JFrame {
	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private final JPanel contentPanel = new JPanel();
	private JButton button;
	private JButton button_1;
	public JTextField textField;
	private JButton button_2;
	public int status = -1;

	public AcceptReceive() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent arg0) {
				status = 0;
			}
		});
		
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setResizable(false);
		setAlwaysOnTop(true);
		setBounds(100, 300, 400, 190);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		setTitle("  Xác nhận lưu dữ liệu");
		
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JTextArea txtrCDLiu = new JTextArea();
			txtrCDLiu.setEditable(false);
			txtrCDLiu.setFont(new Font("Monospaced", Font.PLAIN, 13));
			txtrCDLiu.setLineWrap(true);
			txtrCDLiu.setText("Có dữ liệu được gửi đến.\r\nCho phép lưu lại vào thư mục dưới?");
			txtrCDLiu.setBounds(10, 11, 364, 64);
			contentPanel.add(txtrCDLiu);
		}
		
		button = new JButton("OK");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String test = textField.getText();
				if (test.equals("")) {
					JOptionPane.showMessageDialog(rootPane, "Không được để trống vị trí lưu!");
				}
				else {
					File f = new File(test);
					if(f.exists()) {
						status = 1;
					}
					else JOptionPane.showMessageDialog(rootPane, "Vị trí lưu không đúng!");
				}
			}
		});
		button.setFont(new Font("Tahoma", Font.PLAIN, 13));
		button.setActionCommand("OK");
		button.setBounds(122, 122, 49, 25);
		contentPanel.add(button);
		
		button_1 = new JButton("Cancel");
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				status = 0;
			}
		});
		button_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		button_1.setActionCommand("Cancel");
		button_1.setBounds(181, 122, 71, 25);
		contentPanel.add(button_1);
		
		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
			}
		});
		textField.setColumns(10);
		textField.setBounds(10, 85, 285, 25);
		contentPanel.add(textField);
		
		button_2 = new JButton("Duyệt");
		button_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ServerTransferMain.ar.setAlwaysOnTop(false);
				chooseDir();
				ServerTransferMain.ar.setAlwaysOnTop(true);
			}
		});
		button_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		button_2.setBounds(300, 85, 74, 25);
		contentPanel.add(button_2);
	}
	
	// chọn thư mục
	public void chooseDir() {
    	JFileChooser chooser = new JFileChooser();
    	chooser.setLocation(600, 200);
	    chooser.setCurrentDirectory(new java.io.File("."));
	    chooser.setDialogTitle("choosertitle");
	    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	    chooser.setAcceptAllFileFilterUsed(false);
	    if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
	    	textField.setText(chooser.getSelectedFile().getAbsolutePath());
		}
	    
    }

}
