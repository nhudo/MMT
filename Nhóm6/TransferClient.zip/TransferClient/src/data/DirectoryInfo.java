package data;

import java.io.Serializable;
import java.util.ArrayList;

public class DirectoryInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	private String name;
	private ArrayList<DirectoryInfo> childdirectory;
	private ArrayList<FileInfo> fileindirectory;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<DirectoryInfo> getChilddirectory() {
		return childdirectory;
	}

	public void setChilddirectory(ArrayList<DirectoryInfo> childdirectory) {
		this.childdirectory = childdirectory;
	}

	public ArrayList<FileInfo> getFileindirectory() {
		return fileindirectory;
	}

	public void setFileindirectory(ArrayList<FileInfo> fileindirectory) {
		this.fileindirectory = fileindirectory;
	}
}
