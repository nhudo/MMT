package server;


import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import data.Data;
import data.DirectoryInfo;
import data.FileInfo;


public class TCPServer extends Thread {
    // create serverSocket object
    private ServerSocket serverSocket;
    private int port = 9900;

    public void open() {
        try {
            serverSocket = new ServerSocket(port);
//            System.out.println("Server được mở trên cổng: " + port);
            ServerTransferMain.view.getTextArea().append("Server được mở trên cổng: " + port + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        while (true) {
            Socket server = null;
            DataInputStream inFromClient = null;
            ObjectInputStream ois = null;
            ObjectOutputStream oos = null;

            try {
                // chấp nhận MỘT kết nối đến server
            	// nếu có nhiều client cần kết nối đến server thì phải đặt câu lệnh này trong while(true)
            	// nếu không có kết nối đến thì chương trình bị dừng tại đây.
                server = serverSocket.accept();
//                System.out.println("Kết nối đến: " + server.getRemoteSocketAddress());
                ServerTransferMain.view.getTextArea().append("Kết nối đến: " + server.getRemoteSocketAddress() + "\n");

                // lấy dữ liệu truyền đến từ client
                // thông qua hàm getInputStream() có được sau khi đối tượng ServerSocket accept()
                
                // ban đầu client gửi lời chào đến Server, thế nên mới có cái này
                inFromClient = new DataInputStream(server.getInputStream());
//                System.out.println(inFromClient.readUTF());
                ServerTransferMain.view.getTextArea().append(inFromClient.readUTF());

                // nhận file
                ois = new ObjectInputStream(server.getInputStream());
                Data data = (Data) ois.readObject();
                
                if (data != null) {
                	int stt = -1;
                	long finishtime = System.currentTimeMillis() + 30000;
                	ServerTransferMain.ar.setVisible(true);
                    while (true) {
                    	if (stt == 1) {
//                    		System.out.println(stt);
                    		ServerTransferMain.ar.setVisible(false);
                    		String dirPath = ServerTransferMain.ar.textField.getText();
                    		if (data.getStatus() == 1) {
                            	// nhận file
                            	createFile(data.getFileinfo(), dirPath);
                            }
                            else if (data.getStatus() == 2) {
                            	// nhận thư mục
                            	createDir(data.getDirinfo(), dirPath);
                            }
                    		data.setStatus(0);
                    		ServerTransferMain.ar.status = -1;
                    		break;
                    	}
                    	else if (stt == 0) {
//                    		System.out.println(stt);
                    		ServerTransferMain.ar.setVisible(false);
                    		data.setStatus(-1);
                    		ServerTransferMain.ar.status = -1;
                    		break;
                    	}
                    	else if (stt == -1) {
                    		// phải có dòng này, nếu ko có thì chương trình treo ngay, do không tương tác gì
                    		// đoán thế, test mãi mới ra cái lỗi rất vớ vẩn không hiểu kiểu gì
                    		if (System.currentTimeMillis()%5000 == 0) System.out.println();
                    		
                    		stt = ServerTransferMain.ar.status;
                    		if (System.currentTimeMillis() >= finishtime) stt = 0;
                    	}
                    }
                }

                // xác nhận rằng file đã được gửi
                oos = new ObjectOutputStream(server.getOutputStream());
                // đặt lại status và xóa hết dữ liệu kèm theo của data
                // nghĩa là chỉ gửi 1 đối tượng data chỉ chứa status mà không chứa dữ liệu
                
                data.setDirinfo(null);
                data.setFileinfo(null);
                oos.writeObject(data);

            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } finally {
            	ServerTransferMain.view.getTextArea().append("Đóng kết nối với " + server.getRemoteSocketAddress() + "\n");
                // close all stream
                closeStream(ois);
                closeStream(oos);
                closeStream(inFromClient);
                // close session
                closeSocket(server);
            }
        }
    }

    private void createFile(FileInfo fileInfo, String destinationDirPath) {
        BufferedOutputStream bos = null;

        try {
            if (fileInfo != null) {
            	
                File fileReceive = new File(destinationDirPath + "\\" + fileInfo.getFilename());
                System.out.println("Đã nhận file" + fileInfo.getFilename());
                ServerTransferMain.view.getTextArea().append("Đã nhận file" + fileInfo.getFilename() + "\n");
                // nếu file là không tồn tại thì tạo file sau đó ghi vào nội dung của file
                bos = new BufferedOutputStream(new FileOutputStream(fileReceive));
                
                // ghi vào file nội dung của nó
                bos.write(fileInfo.getDataBytes());
                bos.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            closeStream(bos);
        }
    }
    
    private void createDir(DirectoryInfo dirInfo, String destinationDirPath) {
    	if (dirInfo == null) return;
    	File dir = new File(destinationDirPath + "\\" + dirInfo.getName());
    	// nếu thư mục không tồn tại => tạo mới nó
    	dir.mkdir();
    	for (DirectoryInfo x: dirInfo.getChilddirectory()) {
    		createDir(x, destinationDirPath + "\\" + dirInfo.getName());
    	}
    	for (FileInfo x: dirInfo.getFileindirectory()) {
    		createFile(x, destinationDirPath + "\\" + dirInfo.getName());
    	}
    }

    public void closeSocket(Socket socket) {
        try {
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void closeStream(InputStream inputStream) {
        try {
            if (inputStream != null) {
                inputStream.close();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void closeStream(OutputStream outputStream) {
        try {
            if (outputStream != null) {
                outputStream.close();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}