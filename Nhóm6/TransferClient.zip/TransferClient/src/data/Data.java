package data;

import java.io.Serializable;

public class Data implements Serializable {
	private static final long serialVersionUID = 1L;

	private DirectoryInfo dirinfo;
	private FileInfo fileinfo;
	
	// một biến để lưu lại trạng thái của việc truyền dữ liệu
	// status = 0 -> đã nhận, = -1 -> không nhận
	// status = 1 -> truyền file, = 2 -> truyền dir
	private int status;

	public DirectoryInfo getDirinfo() {
		return dirinfo;
	}

	public void setDirinfo(DirectoryInfo dirinfo) {
		this.dirinfo = dirinfo;
	}

	public FileInfo getFileinfo() {
		return fileinfo;
	}

	public void setFileinfo(FileInfo fileinfo) {
		this.fileinfo = fileinfo;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

}
